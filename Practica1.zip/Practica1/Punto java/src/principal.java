
public class principal {

	public static void main (String []args) {
		Punto p= new Punto (3,4);
		System.out.println(p.toString());
		System.out.println("Coordenadas polares"+p.coord_polares());		
	}
}
